import React from 'react'

export default function BakulFresh() {
  return (
    <div>BakulFresh</div>
  )
}
