import React from 'react'

export default function Finshots() {
  return (
    <div>Finshots</div>
  )
}
