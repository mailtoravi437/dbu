import React from 'react'

export default function Vedose() {
  return (
    <div>Vedose</div>
  )
}
